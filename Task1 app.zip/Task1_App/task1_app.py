"""Task 1 — interactive visual group discovery. Run: python task1_app.py"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, ctx, dcc, html, no_update
from dash.exceptions import PreventUpdate

BASE = Path(__file__).resolve().parent
FIELDS = ["PT08.S1(CO)", "C6H6(GT)", "PT08.S3(NOx)", "PT08.S4(NO2)", "PT08.S5(O3)", "T", "RH", "AH"]
LABELS = {"PT08.S1(CO)": "S1 response", "C6H6(GT)": "C6H6 (µg/m³)", "PT08.S3(NOx)": "S3 response", "PT08.S4(NO2)": "S4 response", "PT08.S5(O3)": "S5 response", "T": "T (°C)", "RH": "RH (%)", "AH": "AH (raw units)"}
SEASONS = ["Winter", "Spring", "Summer", "Autumn"]
COLORS = ["#76b7b2", "#f28e2b", "#e15759", "#4e79a7"]
HOUR_COLORS = ["#440154", "#482878", "#3e4989", "#31688e", "#26828e", "#1f9e89", "#35b779", "#6ece58", "#b5de2b", "#fde725"]
LABEL_FIELD = {label: field for field, label in LABELS.items()}
GRAPH_CONFIG = {"displaylogo": False, "responsive": True, "scrollZoom": False, "toImageButtonOptions": {"format": "png", "scale": 2}, "modeBarButtonsToRemove": ["lasso2d", "autoScale2d"]}
RECORDS_PAGE_SIZE = 20


@dataclass
class Data:
    df: pd.DataFrame
    digest: str
    extents: dict
    missing_same: bool


def load_data(path=BASE / "data" / "air_quality_clean.csv") -> Data:
    path = Path(path)
    df = pd.read_csv(path, dtype={"RecordID": str})
    required = ["RecordID", "DateTime", "Hour", "Season", *FIELDS]
    if any(field not in df for field in required):
        raise ValueError("Missing required column")
    if not df.RecordID.is_unique or df.RecordID.isna().any():
        raise ValueError("RecordID must be non-empty and unique")
    df["_time"] = pd.to_datetime(df.DateTime, format="%Y-%m-%dT%H:%M:%S", errors="raise")
    for field in FIELDS:
        df[field] = pd.to_numeric(df[field], errors="raise")
        if df[field].eq(-200).any():
            raise ValueError("Input must be the cleaned file; -200 is not a value")
    if not df.Season.isin(SEASONS).all():
        raise ValueError("Unexpected Season category")
    masks = df[FIELDS].isna()
    missing_same = all(masks[field].equals(masks[FIELDS[0]]) for field in FIELDS)
    extents = {field: [float(df[field].min()), float(df[field].max())] for field in FIELDS}
    return Data(df, hashlib.sha256(path.read_bytes()).hexdigest(), extents, missing_same)


def empty_selection(data, revision=0):
    return {"schema_version": "1.0", "dataset_sha256": data.digest, "selection_active": False, "group_id": None, "required_fields": FIELDS[:],
            "selected_record_ids": [], "bounds": {}, "axis_order": FIELDS[:], "view_type": None,
            "time_filter": {"start_date": str(data.df._time.min().date()), "end_date_inclusive": str(data.df._time.max().date())},
            "missing_excluded_count": int(data.df[FIELDS].isna().any(axis=1).sum()),
            "revision": revision, "review_label": "自由探索 · 尚未定义组", "note": "", "error": ""}


def time_frame(data, start=None, end=None):
    frame = data.df
    if start:
        frame = frame.loc[frame._time >= pd.Timestamp(start)]
    if end:
        frame = frame.loc[frame._time < pd.Timestamp(end) + pd.Timedelta(days=1)]
    complete = frame.dropna(subset=FIELDS)
    return frame, complete


def ranges_list(value):
    """Normalize a single range or multi-range; empty means no axis restriction."""
    if value is None or value == []:
        return []
    if len(value) == 1 and isinstance(value[0], list) and value[0] and isinstance(value[0][0], list):
        value = value[0]
    if len(value) == 2 and not isinstance(value[0], (list, tuple)):
        return [list(value)]
    return [list(pair) for pair in value if isinstance(pair, (list, tuple)) and len(pair) == 2]


def bounds_mask(frame, bounds):
    mask = pd.Series(True, index=frame.index)
    for field, intervals in bounds.items():
        if field not in FIELDS:
            continue
        intervals = ranges_list(intervals)
        if not intervals:
            continue
        axis_mask = pd.Series(False, index=frame.index)
        for lo, hi in intervals:
            part = pd.Series(True, index=frame.index)
            if lo is not None:
                part &= frame[field].ge(float(lo))
            if hi is not None:
                part &= frame[field].le(float(hi))
            axis_mask |= part
        mask &= axis_mask
    return mask


def selected_frame(eligible, selection):
    if not selection.get("selection_active"):
        return eligible
    if selection.get("bounds"):
        return eligible.loc[bounds_mask(eligible, selection["bounds"])]
    return eligible.loc[eligible.RecordID.isin(selection.get("selected_record_ids", []))]


def color_values(frame, mode):
    if mode == "Hour":
        return frame.Hour.astype(int).tolist(), "Viridis", 0, 23
    values = frame.Season.map({season: i for i, season in enumerate(SEASONS)}).tolist()
    scale = []
    for i, color in enumerate(COLORS):
        scale.extend([[i / 4, color], [(i + 1) / 4, color]])
    return values, scale, -0.5, 3.5


def custom_data(frame):
    return frame[["RecordID", "DateTime", "Season", "Hour"]].values.tolist()


def make_marker(frame, mode, size=4):
    values, scale, low, high = color_values(frame, mode)
    result = {"color": values, "colorscale": scale, "cmin": low, "cmax": high,
              "size": size, "opacity": .58, "showscale": mode == "Hour", "line": {"width": 0}}
    if mode == "Hour":
        result["colorbar"] = {"title": "Hour", "tickvals": [0, 6, 12, 18, 23], "thickness": 13}
    return result


def selection_indices(frame, selection):
    if not selection.get("selection_active"):
        return None
    ids = set(selected_frame(frame, selection).RecordID)
    return [i for i, rid in enumerate(frame.RecordID) if rid in ids]


def base_layout(title, height, revision=0):
    return dict(template="plotly_white", title={"text": title, "x": .02, "font": {"size": 17}},
                font={"family": "Arial, Microsoft YaHei, sans-serif", "size": 12, "color": "#263c50"},
                height=height, margin={"l": 75, "r": 35, "t": 60, "b": 55},
                paper_bgcolor="white", plot_bgcolor="white", dragmode="select", selections=[], shapes=[],
                uirevision=f"axes-{revision}", selectionrevision=revision)


def matrix_figure(data, frame, selection, mode):
    fig = go.Figure(go.Splom(dimensions=[dict(label=LABELS[f], values=frame[f].tolist()) for f in FIELDS],
        showupperhalf=False, diagonal={"visible": False}, ids=frame.RecordID.tolist(),
        customdata=custom_data(frame), marker=make_marker(frame, mode, 3), showlegend=False,
        selectedpoints=selection_indices(frame, selection), selected={"marker": {"opacity": .9}},
        unselected={"marker": {"opacity": .07, "color": "#b5bec6"}},
        hovertemplate="%{customdata[0]}<br>%{customdata[1]}<br>%{customdata[2]} · Hour %{customdata[3]}<br>x=%{x:.4g}, y=%{y:.4g}<extra></extra>"))
    fig.update_layout(**base_layout("Scatterplot matrix · all 8 measurement attributes", 1040, selection.get("revision", 0)))
    fig.update_layout(margin={"l": 100, "r": 60, "t": 65, "b": 85})
    for i, field in enumerate(FIELDS):
        key = "" if i == 0 else str(i + 1)
        axis = {"range": data.extents[field], "nticks": 3, "tickfont": {"size": 9}, "title": {"font": {"size": 10}}, "gridcolor": "#e8edf2", "zeroline": False}
        fig.update_layout(**{f"xaxis{key}": axis, f"yaxis{key}": axis})
    return fig


def parallel_figure(data, frame, selection, mode):
    order = selection.get("axis_order", FIELDS)
    if sorted(order) != sorted(FIELDS):
        order = FIELDS[:]
    selected_ids = set(selected_frame(frame, selection).RecordID)
    frame = frame.assign(_selected=frame.RecordID.isin(selected_ids)).sort_values("_selected", kind="stable")
    values, scale, low, high = color_values(frame, mode)
    if selection.get("selection_active"):
        # Add one explicit grey color below the actual color range. Selected lines draw last.
        values = [v if selected else low - 2 for v, selected in zip(values, frame._selected)]
        new_low = low - 2
        start = (low - new_low) / (high - new_low)
        original = go.scatter.Marker(colorscale=scale).colorscale
        scale = [[0, "#e3e8ed"], [max(0, start - 0.00001), "#e3e8ed"]] + [[start + float(p) * (1 - start), color] for p, color in original]
        low = new_low
    dims = []
    for field in order:
        dimension = {"label": LABELS[field], "values": frame[field].tolist(), "range": data.extents[field], "multiselect": True}
        intervals = ranges_list(selection.get("bounds", {}).get(field, []))
        if intervals:
            intervals = [[data.extents[field][0] if a is None else a, data.extents[field][1] if b is None else b] for a, b in intervals]
            dimension["constraintrange"] = intervals[0] if len(intervals) == 1 else intervals
        dims.append(dimension)
    fig = go.Figure(go.Parcoords(dimensions=dims, ids=frame.RecordID.tolist(),
        line={"color": values, "colorscale": scale, "cmin": low, "cmax": high, "showscale": False},
        unselected={"line": {"color": "#cbd5de", "opacity": .12}}, labelfont={"size": 12}, tickfont={"size": 10}))
    fig.update_layout(template="plotly_white", height=450, margin={"l": 70, "r": 75, "t": 100, "b": 45},
        paper_bgcolor="white", font={"family": "Arial, Microsoft YaHei, sans-serif"},
        title={"text": "Parallel coordinates · brush axis intervals", "x": .02, "y": .98, "yref": "container", "yanchor": "top", "font": {"size": 17}},
        uirevision=f"parallel-{selection.get('revision', 0)}")
    return fig


def parse_parallel_restyle(restyle, figure, previous):
    """Map constraintrange changes by current dimension labels, including reordered axes."""
    if not restyle or not isinstance(restyle[0], dict):
        return None
    edits = restyle[0]
    dims = (figure or {}).get("data", [{}])[0].get("dimensions", [])
    order = [LABEL_FIELD.get(dim.get("label")) for dim in dims]
    if sorted(x for x in order if x) != sorted(FIELDS):
        order = previous.get("axis_order", FIELDS[:])
    bounds = dict(previous.get("bounds", {}))
    changed = False
    if "dimensions" in edits:
        new = edits["dimensions"]
        if isinstance(new, list) and len(new) == 1 and isinstance(new[0], list):
            new = new[0]
        if isinstance(new, list) and len(new) == 8 and all(isinstance(d, dict) for d in new):
            new_order = [LABEL_FIELD.get(d.get("label")) for d in new]
            if sorted(x for x in new_order if x) == sorted(FIELDS):
                order = new_order
                bounds = {field: ranges_list(dim["constraintrange"]) for field, dim in zip(order, new) if dim.get("constraintrange")}
                changed = True
    for key, raw in edits.items():
        match = re.match(r"dimensions\[(\d+)\]\.constraintrange$", key)
        if match:
            idx = int(match[1])
            if idx >= len(order):
                continue
            # A restyle value is wrapped once because it targets one trace.
            value = raw[0] if isinstance(raw, list) and len(raw) == 1 else raw
            intervals = ranges_list(value)
            if intervals:
                bounds[order[idx]] = intervals
            else:
                bounds.pop(order[idx], None)
            changed = True
    return (bounds, order) if changed else None


GROUP_COLOURS = {"G1": "#2563eb", "G2": "#f28e2b", "G3": "#9b3fc4"}
GROUP_BOUNDS = {
    "G1": {"C6H6(GT)": [[5, 15]], "PT08.S4(NO2)": [[None, 1100]]},
    "G2": {"C6H6(GT)": [[5, 15]], "PT08.S4(NO2)": [[1700, None]]},
    "G3": {"C6H6(GT)": [[25, None]], "PT08.S1(CO)": [[1400, None]], "T": [[18, 26]], "AH": [[1.4, 1.8]]},
}
_load_master = load_data


def load_data(path=BASE / "data" / "air_quality_clean.csv", groups_path=BASE / "groups.csv"):
    data = _load_master(path)
    groups = pd.read_csv(groups_path, dtype={"RecordID": str}).fillna({"Group": ""})
    if not groups.RecordID.is_unique or not set(groups.Group).issubset({"", "G1", "G2", "G3"}):
        raise ValueError("Invalid final group mapping")
    if set(groups.RecordID) != set(data.df.RecordID):
        raise ValueError("Final groups.csv must contain the same RecordIDs as the master data")
    data.df["Group"] = data.df.RecordID.map(groups.set_index("RecordID").Group)
    data.df["YearMonth"] = data.df._time.dt.to_period("M").astype(str)
    eligible = data.df.dropna(subset=FIELDS)
    for group, bounds in GROUP_BOUNDS.items():
        actual = set(data.df.loc[data.df.Group.eq(group), "RecordID"])
        if actual != set(eligible.loc[bounds_mask(eligible, bounds), "RecordID"]):
            raise ValueError(f"Final {group} membership does not match the saved visual selection")
    return data


def months_for(data):
    return sorted(data.df.YearMonth.unique())


def canonical_bounds(data, bounds):
    return {field: [[data.extents[field][0] if lo is None else lo,
                     data.extents[field][1] if hi is None else hi] for lo, hi in ranges_list(intervals)]
            for field, intervals in bounds.items() if ranges_list(intervals)}


def frames_for(data, month_range):
    months = months_for(data)
    lo, hi = month_range or [0, len(months) - 1]
    frame = data.df.loc[data.df.YearMonth.isin(months[lo:hi + 1])]
    return frame, frame.dropna(subset=FIELDS)


def sync_selection(data, selection, month_range):
    selection = copy.deepcopy(selection)
    frame, eligible = frames_for(data, month_range)
    if selection.get("selection_active"):
        if selection.get("bounds"):
            chosen = eligible.loc[bounds_mask(eligible, selection["bounds"])]
        else:
            chosen = eligible.loc[eligible.RecordID.isin(selection.get("origin_record_ids", []))]
        selection["selected_record_ids"] = chosen.RecordID.tolist()
    else:
        selection["selected_record_ids"] = []
    selection["time_filter"] = {"start_date": str(frame._time.min().date()), "end_date_inclusive": str(frame._time.max().date())}
    selection["missing_excluded_count"] = len(frame) - len(eligible)
    return selection


def select_group(data, group, previous=None):
    selection = empty_selection(data, (previous or {}).get("revision", 0) + 1)
    selection["origin_record_ids"] = []
    if group in GROUP_BOUNDS:
        selection.update(selection_active=True, group_id=group, bounds=copy.deepcopy(GROUP_BOUNDS[group]),
                         origin_record_ids=data.df.loc[data.df.Group.eq(group), "RecordID"].tolist(), view_type="final_group")
    return selection


def brushed_selection(data, payload, previous, source):
    if not payload or (not payload.get("points") and not payload.get("range") and not payload.get("lassoPoints")):
        return None
    valid_ids = set(data.df.dropna(subset=FIELDS).RecordID)
    ids = []
    for point in payload.get("points", []):
        custom = point.get("customdata")
        rid = custom[0] if isinstance(custom, (list, tuple)) and custom else point.get("id")
        if rid in valid_ids:
            ids.append(rid)
    selection = empty_selection(data, previous.get("revision", 0) + 1)
    selection.update(selection_active=True, group_id=None, origin_record_ids=list(dict.fromkeys(ids)),
                     axis_order=previous.get("axis_order", FIELDS[:]), view_type=source)
    return selection


def selection_caption(frame, selection):
    if not selection.get("selection_active"):
        return f"All hours · {len(frame):,}"
    return f"{selection.get('group_id') or 'Selection'} · {len(selected_frame(frame, selection)):,} / {len(frame):,} hours"


def colour_key(mode):
    if mode == "Hour":
        return [html.Span("Hour"), html.Span(className="hour-gradient"), html.Span("00 — 23")]
    return [html.Span([html.I(style={"backgroundColor": color}), season], className="legend-item")
            for season, color in zip(SEASONS, COLORS)]


SHORT_LABELS = dict(zip(FIELDS, ["S1", "C6H6", "S3", "S4", "S5", "T", "RH", "AH"]))
PC_LABELS = dict(zip(FIELDS, ["S1<br>response", "C6H6<br>µg/m³", "S3<br>response", "S4<br>response", "S5<br>response", "T<br>°C", "RH<br>%", "AH<br>raw units"]))
LABEL_FIELD.update({label: field for field, label in PC_LABELS.items()})


def figures(data, selection, month_range, mode):
    _, eligible = frames_for(data, month_range)
    selection = sync_selection(data, selection, month_range)
    pc = parallel_figure(data, eligible, selection, mode)
    pc.update_layout(title_text="Parallel coordinates", height=460,
                     margin={"l": 48, "r": 48, "t": 108, "b": 42},
                     title_font_size=19, font_color="#263c50")
    pc.data[0].labelfont = {"size": 13, "color": "#22384b"}
    pc.data[0].tickfont = {"size": 11, "color": "#536677"}
    pc.data[0].rangefont = {"size": 1, "color": "rgba(0,0,0,0)"}
    translucent = []
    for position, color in pc.data[0].line.colorscale:
        if color.startswith("#"):
            rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5))
            alpha = .32 if selection.get("selection_active") and color != "#e3e8ed" else .055
            color = f"rgba({rgb[0]},{rgb[1]},{rgb[2]},{alpha})"
        translucent.append([position, color])
    pc.data[0].line.colorscale = translucent
    for dim, field in zip(pc.data[0].dimensions, selection.get("axis_order", FIELDS)):
        dim.label = PC_LABELS[field]
        dim.tickformat = ".2f" if field == "AH" else (".1f" if field in ["C6H6(GT)", "T"] else ".0f")
    matrix = matrix_figure(data, eligible, selection, mode)
    matrix.update_layout(title_text="Scatterplot matrix", height=830, title_font_size=19,
                         margin={"l": 65, "r": 22, "t": 50, "b": 65})
    for dim, field in zip(matrix.data[0].dimensions, FIELDS):
        dim.label = SHORT_LABELS[field]
    matrix.data[0].marker.showscale = False
    matrix.data[0].showupperhalf = True
    matrix.data[0].diagonal.visible = True
    matrix.data[0].marker.size = 3
    matrix.data[0].marker.opacity = .36
    matrix.data[0].unselected.marker.opacity = .06
    matrix.data[0].hovertemplate = "%{customdata[1]}<br>%{customdata[0]}<br>%{customdata[2]} · %{customdata[3]}:00<br>x: %{x:.4g} · y: %{y:.4g}<extra></extra>"
    for i in range(8):
        suffix = "" if i == 0 else str(i+1)
        for direction in ["x", "y"]:
            matrix.update_layout(**{f"{direction}axis{suffix}": {"nticks": 3, "tickfont": {"size": 10}, "title": {"font": {"size": 12}}, "gridcolor": "#edf0f3"}})
    return pc, matrix


def make_layout(data, prefix="t1"):
    sid = lambda name: f"{prefix}-{name}"
    months = months_for(data)
    def control(label, name, options, value, width):
        return html.Div([html.Label(label, htmlFor=sid(name)), dcc.Dropdown(options, value, id=sid(name), clearable=False)], style={"width": width})
    return html.Div(className="task1-app", children=[
        dcc.Store(id=sid("selection"), data=sync_selection(data, select_group(data, "All"), [0, len(months)-1])),
        html.H2("Task 1 - Discovery of Pollution Groups"),
        html.Div(className="control-row", children=[
            control("Group", "group", [{"label": "All hours", "value": "All"}, *[{"label": g, "value": g} for g in GROUP_BOUNDS], {"label": "Custom selection", "value": "Custom", "disabled": True}], "All", "200px"),
            control("Colour by", "colour", ["Season", "Hour"], "Season", "180px"),
            html.Button("Clear selection", id=sid("clear"), n_clicks=0),
        ]),
        html.Div([html.Label("Month range"), dcc.RangeSlider(0, len(months)-1, 1, value=[0, len(months)-1], id=sid("months"),
            marks={i: pd.Timestamp(m).strftime("%b %Y") for i,m in enumerate(months) if i % 2 == 0 or i == len(months)-1},
            allowCross=False, allow_direct_input=False)], className="month-control"),
        html.Div(html.Div(colour_key("Season"), id=sid("legend"), className="colour-legend"), className="chart-key"),
        html.Div(dcc.Graph(id=sid("parallel"), config=GRAPH_CONFIG, style={}), id=sid("parallel-container")),
        dcc.Graph(id=sid("matrix"), config=GRAPH_CONFIG, style={}),
    ])


def register_callbacks(app, data, prefix="t1"):
    sid = lambda name: f"{prefix}-{name}"

    @app.callback(Output(sid("selection"), "data"), Output(sid("group"), "value"),
                  Input(sid("group"), "value"), Input(sid("clear"), "n_clicks"), Input(sid("months"), "value"),
                  Input(sid("matrix"), "selectedData"), Input(sid("parallel"), "restyleData"),
                  State(sid("selection"), "data"), State(sid("parallel"), "figure"), prevent_initial_call=True)
    def reduce(group, clear, month_range, matrix_payload, restyle, previous, pc_figure):
        triggered = ctx.triggered_id
        selection = copy.deepcopy(previous or select_group(data, "All"))
        group_out = no_update
        if triggered == sid("clear"):
            selection = select_group(data, "All", previous)
            group_out = "All"
        elif triggered == sid("group"):
            if group == "Custom":
                raise PreventUpdate
            selection = select_group(data, group, previous)
        elif triggered == sid("months"):
            selection["revision"] += 1
        elif triggered == sid("parallel"):
            parsed = parse_parallel_restyle(restyle, pc_figure, previous)
            if parsed is None:
                raise PreventUpdate
            bounds, order = parsed
            only_order = canonical_bounds(data, bounds) == canonical_bounds(data, previous.get("bounds", {}))
            if only_order and order == previous.get("axis_order", FIELDS):
                raise PreventUpdate
            if only_order:
                bounds = previous.get("bounds", {})
            selection.update(bounds=bounds, axis_order=order, revision=selection.get("revision", 0) + 1)
            if not only_order:
                selection.update(selection_active=bool(bounds), group_id=None, origin_record_ids=[], view_type="parallel")
                group_out = "Custom" if bounds else "All"
        else:
            selection = brushed_selection(data, matrix_payload, previous, "matrix")
            if selection is None:
                raise PreventUpdate
            group_out = "Custom"
        return sync_selection(data, selection, month_range), group_out

    @app.callback(Output(sid("parallel-container"), "children"), Output(sid("matrix"), "figure"),
                  Output(sid("legend"), "children"),
                  Input(sid("selection"), "data"), Input(sid("colour"), "value"), State(sid("months"), "value"))
    def render(selection, mode, month_range):
        frame, eligible = frames_for(data, month_range)
        selection = sync_selection(data, selection, month_range)
        pc, matrix = figures(data, selection, month_range, mode)
        # Remount the native parallel plot when the selection changes so its
        # private brush state cannot override the shared RecordID selection.
        parallel_view = html.Div(dcc.Graph(id=sid("parallel"), figure=pc, config=GRAPH_CONFIG, style={}),
                                 key=f"parallel-{selection.get('revision', 0)}-{mode}")
        return parallel_view, matrix, colour_key(mode)


def create_app():
    data = load_data()
    app = Dash(__name__, assets_folder=str(BASE / "assets"), title="Task 1 - Pollution Groups", update_title=None)
    app.layout = make_layout(data)
    register_callbacks(app, data)
    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8051)
    args = parser.parse_args()
    create_app().run(host="127.0.0.1", port=args.port, debug=False)
